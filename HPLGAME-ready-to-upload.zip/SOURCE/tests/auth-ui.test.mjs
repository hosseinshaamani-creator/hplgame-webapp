// Contract tests using the real SDK and a stub HTTP server. NOT live Supabase verification.
import test from 'node:test';import assert from 'node:assert/strict';import {JSDOM} from 'jsdom';
const wait=ms=>new Promise(r=>setTimeout(r,ms));
test('auth UI validates, masks passwords, submits once and uses real SDK endpoints',{timeout:15000},async t=>{
 const dom=new JSDOM('<div id="app"></div>',{url:'https://hplgame.example/hplgame-webapp/#/signup',pretendToBeVisual:true});const w=dom.window;t.after(()=>w.close());w.scrollTo=()=>{};
 for(const key of ['window','document','location','localStorage','sessionStorage','FormData'])globalThis[key]=key==='window'?w:w[key];Object.defineProperty(globalThis,'navigator',{value:w.navigator,configurable:true});
 globalThis.requestAnimationFrame=()=>1;globalThis.cancelAnimationFrame=()=>{};
 // Node BroadcastChannel keeps the process alive; this fixture represents a browser without it.
 globalThis.BroadcastChannel=undefined;
 const {config}=await import('../config.js');config.supabaseUrl='https://hpltest.supabase.co';config.supabaseAnonKey='test-public-key';
 const user={id:'00000000-0000-4000-8000-000000000001',email:'a@example.test',aud:'authenticated',role:'authenticated',user_metadata:{}};
 const requests=[];let duplicate=false;
 const encode=data=>Buffer.from(JSON.stringify(data)).toString('base64url'),jwt=encode({alg:'HS256'})+'.'+encode({sub:user.id,exp:Math.floor(Date.now()/1000)+3600,aud:'authenticated',role:'authenticated'})+'.test-signature';
 globalThis.fetch=async(url,options={})=>{
  const parsed=new URL(url),body=options.body?JSON.parse(options.body):null;requests.push({path:parsed.pathname,body});await wait(20);
  let response={},status=200;
  if(parsed.pathname.endsWith('/signup')){if(duplicate){response={msg:'User already registered',code:'user_already_exists'};status=422;}else response={...user,identities:[{id:user.id}]};}
  else if(parsed.pathname.endsWith('/token'))response={access_token:jwt,refresh_token:'test-refresh',expires_in:3600,token_type:'bearer',user};
  else if(parsed.pathname.endsWith('/user'))response=user;
  else if(parsed.pathname.endsWith('/profiles'))response={id:user.id,email:user.email,display_name:'نام آزمایشی',role:'student',onboarding_completed:true};
  else if(parsed.pathname.endsWith('/projects')||parsed.pathname.endsWith('/progress'))response=[];
  return new Response(JSON.stringify(response),{status,headers:{'Content-Type':'application/json'}});
 };
 await import('../app.js?auth-contract');await wait(80);
 const q=s=>w.document.querySelector(s),fill=(name,value)=>{const field=q(`[name="${name}"]`);field.value=value;field.dispatchEvent(new w.Event('input',{bubbles:true}));},submit=()=>q('#auth-form').dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));
 fill('email','invalid');fill('phone','12');fill('password','short');fill('confirm','x');submit();assert.match(q('#auth-error-email').textContent,/معتبر/);assert.match(q('#auth-error-phone').textContent,/شماره/);assert.equal(requests.some(r=>r.path.endsWith('/signup')),false);
 fill('email','a@example.test');fill('phone','۰۹۱۲۳۴۵۶۷۸۹');fill('password','A-long-test-pass-123!');fill('confirm','A-long-test-pass-123!');q('[name="accountKind"]').value='adult';q('[name="terms"]').checked=true;
 q('[data-target="auth-password"]').click();assert.equal(q('#auth-password').type,'text');q('[data-target="auth-password"]').click();assert.equal(q('#auth-password').type,'password');
 submit();submit();assert.equal(q('[type="submit"]').disabled,true);await wait(100);assert.equal(requests.filter(r=>r.path.endsWith('/signup')).length,1);assert.equal(requests.find(r=>r.path.endsWith('/signup')).body.data.phone,'+989123456789');assert.equal(q('#auth-password').value,'');assert.match(q('#auth-message').textContent,/تأیید/);
 duplicate=true;fill('email','a@example.test');fill('phone','09123456789');fill('password','A-long-test-pass-123!');fill('confirm','A-long-test-pass-123!');q('[name="accountKind"]').value='adult';q('[name="terms"]').checked=true;submit();await wait(100);assert.match(q('#auth-message').textContent,/قبلاً ثبت/);
 w.location.hash='#/forgot';await wait(30);fill('email','a@example.test');submit();await wait(100);assert.ok(requests.some(r=>r.path.endsWith('/recover')));assert.match(q('#auth-message').textContent,/پیوند بازیابی/);
 w.location.hash='#/login';await wait(30);fill('email','a@example.test');fill('password','A-long-test-pass-123!');submit();await wait(250);assert.match(q('h1').textContent,/نام آزمایشی/);assert.ok(requests.some(r=>r.path.endsWith('/token')));assert.equal(JSON.stringify([...Array(w.localStorage.length)].map((_,i)=>w.localStorage.getItem(w.localStorage.key(i)))).includes('test-pass'),false);
 const {getClient}=await import('../lib/backend.js');const db=await getClient();db.auth.stopAutoRefresh();t.after(()=>db.auth.stopAutoRefresh());
 q('[data-action="logout"]').click();await wait(100);assert.equal(w.document.querySelector('[data-action="logout"]'),null);
});
